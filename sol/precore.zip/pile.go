package sol

//lint:file-ignore ST1005 Error messages are toasted, so need to be capitalized

import (
	"errors"
	"fmt"
	"image"
	"image/color"
	"log"

	"github.com/fogleman/gg"
	"github.com/hajimehoshi/ebiten/v2"
	"oddstream.games/gomps5/schriftbank"
)

const (
	pilemagic uint32 = 0xdeadbeef
)

type FanType int

const (
	FAN_NONE FanType = iota
	FAN_DOWN
	FAN_LEFT
	FAN_RIGHT
	FAN_DOWN3
	FAN_LEFT3
	FAN_RIGHT3
)

type MoveType int

const (
	MOVE_NONE MoveType = iota
	MOVE_ANY
	MOVE_ONE
	MOVE_ONE_PLUS
	MOVE_ONE_OR_ALL
)

const (
	CARD_FACE_FAN_FACTOR_V = 3.7
	CARD_FACE_FAN_FACTOR_H = 4
	CARD_BACK_FAN_FACTOR   = 8
)

var DefaultFanFactor [7]float64 = [7]float64{
	1.0,                    // FAN_NONE
	CARD_FACE_FAN_FACTOR_V, // FAN_DOWN
	CARD_FACE_FAN_FACTOR_H, // FAN_LEFT,
	CARD_FACE_FAN_FACTOR_H, // FAN_RIGHT,
	CARD_FACE_FAN_FACTOR_V, // FAN_DOWN3,
	CARD_FACE_FAN_FACTOR_H, // FAN_LEFT3,
	CARD_FACE_FAN_FACTOR_H, // FAN_RIGHT3,
}

const (
	RECYCLE_RUNE   = rune(0x2672)
	NORECYCLE_RUNE = rune(0x2613)
)

// Base is a generic container for cards
type Pile struct {
	magic       uint32
	category    string // just for debugging and checking, never really used
	slot        image.Point
	fanType     FanType
	moveType    MoveType
	subtype     SubtypeAPI
	cards       []*Card
	pos         image.Point
	pos1        image.Point // waste pos #1
	pos2        image.Point // waste pos #1
	fanFactor   float64
	scrunchDims image.Point
	buddyPos    image.Point
	label       string
	symbol      rune
	img         *ebiten.Image
	target      bool // experimental, might delete later, IDK
}

func (p *Pile) Ctor(subtype SubtypeAPI, category string, slot image.Point, fanType FanType, moveType MoveType) {
	// static
	p.magic = pilemagic
	p.category = category
	p.slot = slot
	p.fanType = fanType
	p.moveType = moveType
	p.subtype = subtype
	// dynamic
	p.fanFactor = DefaultFanFactor[p.fanType]
	p.cards = nil
	// downright ugly design kludge
	TheBaize.piles = append(TheBaize.piles, p)
}

func (p *Pile) Valid() bool {
	return p != nil && p.magic == pilemagic
}

func (p *Pile) Reset() {
	p.cards = p.cards[:0]
	p.fanFactor = DefaultFanFactor[p.fanType]
}

// Hidden returns true if this is off screen
func (p *Pile) Hidden() bool {
	return p.slot.X < 0 || p.slot.Y < 0
}

func (p *Pile) IsStock() bool {
	_, ok := (p.subtype).(*Stock)
	return ok
}

func (p *Pile) IsTableau() bool {
	_, ok := (p.subtype).(*Tableau)
	return ok
}

func (p *Pile) Label() string {
	return p.label
}

func (p *Pile) SetLabel(label string) {
	if p.label != label {
		if p.IsTableau() && ThePreferences.Relaxed && TheBaize.script.Info().relaxable {
		} else {
			p.label = label
			TheBaize.setFlag(dirtyPileBackgrounds)
		}
	}
}

func (p *Pile) Rune() rune {
	return p.symbol
}

func (p *Pile) SetRune(symbol rune) {
	if p.symbol != symbol {
		p.symbol = symbol
		TheBaize.setFlag(dirtyPileBackgrounds)
	}
}

// Empty returns true if this pile is empty.
// for use outside this chunk
func (p *Pile) Empty() bool {
	return len(p.cards) == 0
}

// Len returns the number of cards in this pile.
// Len satisfies the sort.Interface interface.
// for use outside this chunk
func (p *Pile) Len() int {
	return len(p.cards)
}

// Less satisfies the sort.Interface interface
func (p *Pile) Less(i, j int) bool {
	c1 := p.cards[i]
	c2 := p.cards[j]
	return c1.Suit() < c2.Suit() && c1.Ordinal() < c2.Ordinal()
}

// Swap satisfies the sort.Interface interface
func (p *Pile) Swap(i, j int) {
	p.cards[i], p.cards[j] = p.cards[j], p.cards[i]
}

// Get a *Card from this collection
func (p *Pile) Get(i int) *Card {
	return p.cards[i]
}

// Append a *Card to this collection
func (p *Pile) Append(c *Card) {
	p.cards = append(p.cards, c)
}

// Peek topmost Card of this Pile (a stack)
func (p *Pile) Peek() *Card {
	if len(p.cards) == 0 {
		return nil
	}
	return p.cards[len(p.cards)-1]
}

// Pop a Card off the end of this Pile (a stack)
func (p *Pile) Pop() *Card {
	if len(p.cards) == 0 {
		return nil
	}
	c := p.cards[len(p.cards)-1]
	p.cards = p.cards[:len(p.cards)-1]
	c.SetOwner(nil)
	c.FlipUp()
	p.Scrunch()
	return c
}

// Push a Card onto the end of this Pile (a stack)
func (p *Pile) Push(c *Card) {
	// c.StopSpinning()

	var pos image.Point
	if len(p.cards) == 0 {
		pos = p.pos
	} else {
		pos = p.PosAfter(p.Peek()) // get this BEFORE appending card
	}

	p.cards = append(p.cards, c)
	c.SetOwner(p)
	c.TransitionTo(pos)

	if p.IsStock() {
		c.FlipDown()
	}
	p.Scrunch()
}

// Slot returns the virtual slot this pile is positioned at
// TODO to use fractional slots, scale the slot values up by, say, 10
func (p *Pile) Slot() image.Point {
	return p.slot
}

// SetBaizePos sets the position of this Pile in Baize coords,
// and also sets the auxillary waste pile fanned positions
func (p *Pile) SetBaizePos(pos image.Point) {
	p.pos = pos
	switch p.fanType {
	case FAN_DOWN3:
		p.pos1.X = p.pos.X
		p.pos1.Y = p.pos.Y + int(float64(CardHeight)/CARD_FACE_FAN_FACTOR_V)
		p.pos2.X = p.pos.X
		p.pos2.Y = p.pos1.Y + int(float64(CardHeight)/CARD_FACE_FAN_FACTOR_V)
	case FAN_LEFT3:
		p.pos1.X = p.pos.X - int(float64(CardWidth)/CARD_FACE_FAN_FACTOR_H)
		p.pos1.Y = p.pos.Y
		p.pos2.X = p.pos1.X - int(float64(CardWidth)/CARD_FACE_FAN_FACTOR_H)
		p.pos2.Y = p.pos.Y
	case FAN_RIGHT3:
		p.pos1.X = p.pos.X + int(float64(CardWidth)/CARD_FACE_FAN_FACTOR_H)
		p.pos1.Y = p.pos.Y
		p.pos2.X = p.pos1.X + int(float64(CardWidth)/CARD_FACE_FAN_FACTOR_H)
		p.pos2.Y = p.pos.Y
	}
	// println(base.category, base.pos.X, base.pos.Y)
}

func (p *Pile) BaizePos() image.Point {
	return p.pos
}

func (p *Pile) ScreenPos() image.Point {
	return p.pos.Add(TheBaize.dragOffset)
}

func (p *Pile) BaizeRect() image.Rectangle {
	var r image.Rectangle
	r.Min = p.pos
	r.Max = r.Min.Add(image.Point{CardWidth, CardHeight})
	return r
}

func (p *Pile) ScreenRect() image.Rectangle {
	var r image.Rectangle = p.BaizeRect()
	r.Min = r.Min.Add(TheBaize.dragOffset)
	r.Max = r.Max.Add(TheBaize.dragOffset)
	return r
}

func (p *Pile) FannedBaizeRect() image.Rectangle {
	var r image.Rectangle = p.BaizeRect()
	if len(p.cards) > 1 {
		var c *Card = p.Peek()
		if c.Dragging() {
			return r
		}
		var cPos = c.BaizePos()
		switch p.fanType {
		case FAN_NONE:
			// do nothing
		case FAN_RIGHT, FAN_RIGHT3:
			r.Max.X = cPos.X + CardWidth
		case FAN_LEFT, FAN_LEFT3:
			r.Max.X = cPos.X - CardWidth
		case FAN_DOWN, FAN_DOWN3:
			r.Max.Y = cPos.Y + CardHeight
		}
	}
	return r
}

func (p *Pile) FannedScreenRect() image.Rectangle {
	var r image.Rectangle = p.FannedBaizeRect()
	r.Min = r.Min.Add(TheBaize.dragOffset)
	r.Max = r.Max.Add(TheBaize.dragOffset)
	return r
}

// PosAfter returns the position of the next card
func (p *Pile) PosAfter(c *Card) image.Point {
	if len(p.cards) == 0 {
		return p.pos
	}
	var pos image.Point
	if c.Transitioning() {
		pos = c.dst
	} else {
		pos = c.pos
	}
	// TODO
	// if pos.X == 0 && pos.Y == 0 {
	// 	println("zero pos in PosAfter", p.category)
	// }
	switch p.fanType {
	case FAN_NONE:
		// nothing to do
	case FAN_DOWN:
		if c.Prone() {
			pos.Y += int(float64(CardHeight) / float64(CARD_BACK_FAN_FACTOR))
		} else {
			pos.Y += int(float64(CardHeight) / p.fanFactor)
		}
	case FAN_LEFT:
		if c.Prone() {
			pos.X -= int(float64(CardWidth) / float64(CARD_BACK_FAN_FACTOR))
		} else {
			pos.X -= int(float64(CardWidth) / p.fanFactor)
		}
	case FAN_RIGHT:
		if c.Prone() {
			pos.X += int(float64(CardWidth) / float64(CARD_BACK_FAN_FACTOR))
		} else {
			pos.X += int(float64(CardWidth) / p.fanFactor)
		}
	case FAN_DOWN3, FAN_LEFT3, FAN_RIGHT3:
		switch len(p.cards) {
		case 0:
			// nothing to do
		case 1:
			pos = p.pos1 // incoming card at slot 1
		case 2:
			pos = p.pos2 // incoming card at slot 2
		default:
			pos = p.pos2 // incoming card at slot 2
			// top card needs to transition from slot[2] to slot[1]
			i := len(p.cards) - 1
			p.cards[i].TransitionTo(p.pos1)
			// mid card needs to transition from slot[1] to slot[0]
			// all other cards to slot[0]
			for i > 0 {
				i--
				p.cards[i].TransitionTo(p.pos)
			}
		}
	}
	return pos
}

func (p *Pile) Refan() {
	var doFan3 bool = false
	switch p.fanType {
	case FAN_NONE:
		for _, c := range p.cards {
			c.TransitionTo(p.pos)
		}
	case FAN_DOWN3, FAN_LEFT3, FAN_RIGHT3:
		for _, c := range p.cards {
			c.TransitionTo(p.pos)
		}
		doFan3 = true
	case FAN_DOWN, FAN_LEFT, FAN_RIGHT:
		var pos = p.pos
		var i = 0
		for _, c := range p.cards {
			c.TransitionTo(pos)
			pos = p.PosAfter(p.cards[i])
			i++
		}
	}

	if doFan3 {
		switch len(p.cards) {
		case 0:
		case 1:
			// nothing to do
		case 2:
			c := p.cards[1]
			c.TransitionTo(p.pos1)
		default:
			i := len(p.cards)
			i--
			c := p.cards[i]
			c.TransitionTo(p.pos2)
			i--
			c = p.cards[i]
			c.TransitionTo(p.pos1)
		}
	}
}

func (p *Pile) IndexOf(card *Card) int {
	for i, c := range p.cards {
		if c == card {
			return i
		}
	}
	return -1
}

func (p *Pile) CanMoveTail(tail []*Card) (bool, error) {
	if AnyCardsProne(tail) {
		return false, errors.New("Cannot move a face down card")
	}
	switch p.moveType {
	case MOVE_NONE:
		return false, fmt.Errorf("Cannot move a card from a %s", p.category)
	case MOVE_ANY:
		// well, that was easy
	case MOVE_ONE:
		if len(tail) > 1 {
			return false, fmt.Errorf("Can only move one card from a %s", p.category)
		}
	case MOVE_ONE_PLUS:
		// don't know destination, so we allow this as MOVE_ANY
	case MOVE_ONE_OR_ALL:
		if len(tail) == 1 {
			// that's okay
		} else if len(tail) == p.Len() {
			// that's okay too
		} else {
			return false, errors.New("Only move one card, or the whole pile")
		}
	}
	return true, nil
}

func (p *Pile) MakeTail(c *Card) []*Card {
	var tail []*Card
	if len(p.cards) > 0 {
		for i, pc := range p.cards {
			if pc == c {
				tail = p.cards[i:]
				break
			}
		}
	}
	if len(tail) == 0 {
		log.Panic("Pile.makeTail made an empty tail")
	}
	return tail
}

// ApplyToCards applies a function to each card in the pile
// caller must use a method expression, eg (*Card).StartSpinning, yielding a function value
// with a regular first parameter taking the place of the receiver
func (p *Pile) ApplyToCards(fn func(*Card)) {
	for _, c := range p.cards {
		fn(c)
	}
}

func (p *Pile) GenericTailTapped(tail []*Card) {
	if len(tail) != 1 {
		return
	}
	c := tail[0]
	for _, fp := range TheBaize.script.Foundations() {
		if ok, _ := fp.subtype.CanAcceptCard(c); ok {
			MoveCard(p, fp)
			break
		}
	}
}

func (p *Pile) GenericCollect() {
	for _, fp := range TheBaize.script.Foundations() {
		for {
			// loop to get as many cards as possible from this pile
			if p.Empty() {
				return
			}
			if ok, _ := fp.subtype.CanAcceptCard(p.Peek()); !ok {
				// this foundation doesn't want this card; onto the next one
				break
			}
			MoveCard(p, fp)
		}
	}
}

// BuryCards moves cards with the specified ordinal to the beginning of the pile
func (p *Pile) BuryCards(ordinal int) {
	tmp := make([]*Card, 0, cap(p.cards))
	for _, c := range p.cards {
		if c.Ordinal() == ordinal {
			tmp = append(tmp, c)
		}
	}
	for _, c := range p.cards {
		if c.Ordinal() != ordinal {
			tmp = append(tmp, c)
		}
	}
	p.cards = p.cards[:0] // keep the underlying array, slice the slice to zero length
	for i := 0; i < len(tmp); i++ {
		p.Push(tmp[i])
	}
}

func (p *Pile) DrawStaticCards(screen *ebiten.Image) {
	for _, c := range p.cards {
		if !(c.Transitioning() || c.Flipping() || c.Dragging()) {
			c.Draw(screen)
		}
	}
}

func (p *Pile) DrawTransitioningCards(screen *ebiten.Image) {
	for _, c := range p.cards {
		if c.Transitioning() {
			c.Draw(screen)
		}
	}
}

func (p *Pile) DrawFlippingCards(screen *ebiten.Image) {
	for _, c := range p.cards {
		if c.Flipping() {
			c.Draw(screen)
		}
	}
}

func (p *Pile) DrawDraggingCards(screen *ebiten.Image) {
	for _, c := range p.cards {
		if c.Dragging() {
			c.Draw(screen)
		}
	}
}

func (p *Pile) Update() {
	for _, card := range p.cards {
		card.Update()
	}
}

func (p *Pile) CreateBackgroundImage() *ebiten.Image {
	if CardWidth == 0 || CardHeight == 0 {
		println("zero dimension in CreateCardShadowImage, unliked in wasm")
		return nil
		// log.Panic("zero dimension in CreateCardShadowImage, unliked in wasm")
	}
	if p.Hidden() {
		// off-screen? don't bother
		return nil
	}
	if _, ok := (p.subtype).(*Reserve); ok {
		// don't draw anything for reserve piles
		return nil
	}
	dc := gg.NewContext(CardWidth, CardHeight)
	dc.SetColor(color.NRGBA{255, 255, 255, 31})
	dc.SetLineWidth(2)
	// draw the RoundedRect entirely INSIDE the context
	dc.DrawRoundedRectangle(1, 1, float64(CardWidth-2), float64(CardHeight-2), CardCornerRadius)
	switch (p.subtype).(type) {
	case *Discard:
		dc.Fill()
	default:
		if p.symbol != 0 {
			// usually the recycle symbol
			dc.SetFontFace(schriftbank.CardSymbolLarge)
			dc.DrawStringAnchored(string(p.symbol), float64(CardWidth)*0.5, float64(CardHeight)*0.45, 0.5, 0.5)
		} else if p.label != "" {
			// usually the "place card in an empty pile" constraint
			dc.SetFontFace(schriftbank.CardOrdinalLarge)
			dc.DrawStringAnchored(p.label, float64(CardWidth)*0.5, float64(CardHeight)*0.45, 0.5, 0.5)
		}
	}
	dc.Stroke()
	return ebiten.NewImageFromImage(dc.Image())
}

func (p *Pile) Draw(screen *ebiten.Image) {
	if p.img == nil {
		return
	}
	op := &ebiten.DrawImageOptions{}
	op.GeoM.Translate(float64(p.pos.X+TheBaize.dragOffset.X), float64(p.pos.Y+TheBaize.dragOffset.Y))
	if p.target && len(p.cards) == 0 {
		// op.GeoM.Translate(-4, -4)
		// screen.DrawImage(CardHighlightImage, op)
		// op.GeoM.Translate(4, 4)
		op.ColorM.Scale(0.75, 0.75, 0.75, 1)
	}

	if p.symbol != 0 {
		if pt := image.Pt(ebiten.CursorPosition()); pt.In(p.ScreenRect()) {
			if ebiten.IsMouseButtonPressed(ebiten.MouseButtonLeft) {
				op.GeoM.Translate(2, 2)
			}
		}
	}
	screen.DrawImage(p.img, op)
}
